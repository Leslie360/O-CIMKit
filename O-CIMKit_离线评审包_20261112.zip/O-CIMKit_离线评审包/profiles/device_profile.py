import os
import json
import numpy as np
from typing import Optional, Dict, Any, List, Union

class DeviceProfile:
    """
    Unified representation of an Organic Device (memristor, transistor, OFET, OECT, etc.)
    defining its physical properties, non-linearities, quantization states, and noise limits.
    """
    def __init__(self, name: str, device_type: str = "memristor", **kwargs: Any) -> None:
        """
        Initializes a DeviceProfile.
        
        Args:
            name (str): Unique name identifier for the device profile.
            device_type (str): Type of device, e.g. "memristor", "oect". Default: "memristor".
            **kwargs: Additional dynamic and fitting parameters.
        """
        self.device_name = name
        self.device_type = device_type
        
        # 1. Dynamic behavior / Memory properties
        self.is_volatile = kwargs.get("is_volatile", False)
        self.tau_volatile = kwargs.get("tau_volatile", None)  # volatile decay constant (seconds)
        self.leaking_rate_volatile = kwargs.get("leaking_rate_volatile", None)
        
        self.is_nonvolatile = kwargs.get("is_nonvolatile", True)
        self.discrete_states_count = kwargs.get("discrete_states_count", None) # None means analog/continuous
        
        # 2. Electrical / Conductance properties
        self.conductance_min = kwargs.get("conductance_min", 1.0)
        self.conductance_max = kwargs.get("conductance_max", 10.0)
        self.noise_std_ratio = kwargs.get("noise_std_ratio", 0.0)  # noise relative to conductance range

        # 3. LTP / LTD Non-linearity Coefficients (3rd-order polynomials)
        self.ltp_poly_coefficients = kwargs.get("ltp_poly_coefficients", [0.0, 0.0, 0.0, 0.0])
        self.ltd_poly_coefficients = kwargs.get("ltd_poly_coefficients", [0.0, 0.0, 0.0, 0.0])
        self.source_metadata = kwargs.get("source_metadata", {})

        # Calculate leaking rate if tau is provided
        if self.is_volatile and self.tau_volatile is not None and self.leaking_rate_volatile is None:
            # Alpha leaking rate matching ESN discrete updates: alpha = 1 - exp(-1/tau)
            self.leaking_rate_volatile = float(1.0 - np.exp(-1.0 / self.tau_volatile))

    @classmethod
    def from_json(cls, json_path: str) -> "DeviceProfile":
        """Load a device profile, using an optional per-process benchmark overlay."""
        overlay_dir = os.environ.get("OCIMKIT_PROFILE_OVERLAY_DIR")
        if overlay_dir:
            overlay_path = os.path.join(overlay_dir, os.path.basename(json_path))
            if os.path.isfile(overlay_path):
                json_path = overlay_path
        with open(json_path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        kwargs = {}
        if "dynamic_parameters" in data:
            kwargs.update(data["dynamic_parameters"])
        if "fitting_parameters" in data:
            kwargs.update(data["fitting_parameters"])
        if "source_metadata" in data:
            kwargs["source_metadata"] = data["source_metadata"]

        return cls(
            name=data["device_name"],
            device_type=data.get("device_type", "memristor"),
            **kwargs
        )

    def to_json(self, json_path: str) -> None:
        """Save device profile configuration to JSON file."""
        data = {
            "device_name": self.device_name,
            "device_type": self.device_type,
            "dynamic_parameters": {
                "is_volatile": self.is_volatile,
                "tau_volatile": self.tau_volatile,
                "leaking_rate_volatile": self.leaking_rate_volatile,
                "is_nonvolatile": self.is_nonvolatile,
                "discrete_states_count": self.discrete_states_count
            },
            "fitting_parameters": {
                "conductance_min": self.conductance_min,
                "conductance_max": self.conductance_max,
                "noise_std_ratio": self.noise_std_ratio,
                "ltp_poly_coefficients": list(self.ltp_poly_coefficients),
                "ltd_poly_coefficients": list(self.ltd_poly_coefficients)
            }
        }
        if self.source_metadata:
            data["source_metadata"] = self.source_metadata

        os.makedirs(os.path.dirname(json_path), exist_ok=True)
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=4, ensure_ascii=False)

    def map_to_physical(self, w_math: Union[float, np.ndarray, Any]) -> Union[float, np.ndarray, Any]:
        """
        Map mathematical weights [-1, 1] to physical conductance [G_min, G_max].
        
        Args:
            w_math (Union[float, np.ndarray, Any]): Mathematical weights.
            
        Returns:
            Union[float, np.ndarray, Any]: Physical conductances.
        """
        w_norm = (w_math + 1.0) / 2.0
        w_phys = w_norm * (self.conductance_max - self.conductance_min) + self.conductance_min
        return w_phys

    def map_to_math(self, w_phys: Union[float, np.ndarray, Any]) -> Union[float, np.ndarray, Any]:
        """
        Map physical conductance [G_min, G_max] back to mathematical weights [-1, 1].
        
        Args:
            w_phys (Union[float, np.ndarray, Any]): Physical conductances.
            
        Returns:
            Union[float, np.ndarray, Any]: Mathematical weights.
        """
        w_norm = (w_phys - self.conductance_min) / (self.conductance_max - self.conductance_min)
        w_math = w_norm * 2.0 - 1.0
        return w_math

    def get_noise_std(self) -> float:
        """
        Calculate the absolute noise standard deviation in Siemens/Amperes.
        
        Returns:
            float: Absolute noise standard deviation.
        """
        return float((self.conductance_max - self.conductance_min) * self.noise_std_ratio)
